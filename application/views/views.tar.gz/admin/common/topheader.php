<div class="navbar navbar-inverse navbar-fixed-top">
	<!-- start: TOP NAVIGATION CONTAINER -->
	<div class="container">
		<div class="navbar-header">
			<!-- start: RESPONSIVE MENU TOGGLER -->
			<button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button">
				<span class="clip-list-2"></span>
			</button>
			<!-- end: RESPONSIVE MENU TOGGLER -->
			<!-- start: LOGO -->
			<a class="navbar-brand" href="<?php echo base_url(); ?>dashboard">
				JOB <i class="fa fa-briefcase"></i><span style="color:#EF6C00"> HUNTER</span> ADMIN
			</a>
			<!-- end: LOGO -->
		</div>
		<div class="navbar-tools">
			<!-- start: TOP NAVIGATION MENU -->
			<ul class="nav navbar-right">
				<!-- start: TO-DO DROPDOWN -->
				<li class="dropdown">
					<a data-toggle="dropdown" data-hover="dropdown" class="dropdown-toggle" data-close-others="true" href="#">
						<i class="clip-list-5"></i>
						<span class="badge"> 12</span>
					</a>					
				</li>
				<!-- end: TO-DO DROPDOWN-->
				<!-- start: NOTIFICATION DROPDOWN -->
				<li class="dropdown">
					<a data-toggle="dropdown" data-hover="dropdown" class="dropdown-toggle" data-close-others="true" href="#">
						<i class="clip-notification-2"></i>
						<span class="badge"> 11</span>
					</a>					
				</li>
				<!-- end: NOTIFICATION DROPDOWN -->
				<!-- start: MESSAGE DROPDOWN -->
				<li class="dropdown">
					<a class="dropdown-toggle" data-close-others="true" data-hover="dropdown" data-toggle="dropdown" href="#">
						<i class="clip-bubble-3"></i>
						<span class="badge"> 9</span>
					</a>					
				</li>
				<!-- end: MESSAGE DROPDOWN -->
				<!-- start: USER DROPDOWN -->
				<li class="dropdown current-user">
					<a data-toggle="dropdown" data-hover="dropdown" class="dropdown-toggle" data-close-others="true" href="#">
						<img src="<?php echo base_url() ?>assets/admin/images/avatar-1-small.jpg" class="circle-img" alt="">
						<span class="username">James Cooper</span>
						<i class="clip-chevron-down"></i>
					</a>
					<ul class="dropdown-menu">
						<li>
							<a href="#">
								<i class="clip-user-2"></i>
								&nbsp;My Profile
							</a>
						</li>												
						<li>
							<a href="#">
								<i class="clip-exit"></i>
								&nbsp;Log Out
							</a>
						</li>
					</ul>
				</li>
				<!-- end: USER DROPDOWN -->				
			</ul>
			<!-- end: TOP NAVIGATION MENU -->
		</div>
	</div>
	<!-- end: TOP NAVIGATION CONTAINER -->
</div>
<!-- end: HEADER -->