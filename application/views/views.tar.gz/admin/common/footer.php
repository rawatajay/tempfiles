<!-- start: MAIN JAVASCRIPTS -->
		<!--[if lt IE 9]>
		<script src="<?php echo base_url() ?>assets/admin/plugins/respond.min.js"></script>
		<script src="<?php echo base_url() ?>assets/admin/plugins/excanvas.min.js"></script>
		<script type="text/javascript" src="<?php echo base_url() ?>assets/admin/plugins/jQuery-lib/1.10.2/jquery.min.js"></script>
		<![endif]-->
		<!--[if gte IE 9]><!-->
		<script src="<?php echo base_url() ?>assets/admin/plugins/jQuery-lib/2.0.3/jquery.min.js"></script>		
		<!--<![endif]-->
		<script src="<?php echo base_url() ?>assets/admin/plugins/jquery-ui/jquery-ui-1.10.2.custom.min.js"></script>
		<script src="<?php echo base_url() ?>assets/admin/plugins/bootstrap/js/bootstrap.min.js"></script>
		<script src="<?php echo base_url() ?>assets/admin/plugins/bootstrap-hover-dropdown/bootstrap-hover-dropdown.min.js"></script>
		<script src="<?php echo base_url() ?>assets/admin/plugins/blockUI/jquery.blockUI.js"></script>
		<script src="<?php echo base_url() ?>assets/admin/plugins/iCheck/jquery.icheck.min.js"></script>
		<script src="<?php echo base_url() ?>assets/admin/plugins/perfect-scrollbar/src/jquery.mousewheel.js"></script>
		<script src="<?php echo base_url() ?>assets/admin/plugins/perfect-scrollbar/src/perfect-scrollbar.js"></script>
		<script src="<?php echo base_url() ?>assets/admin/plugins/less/less-1.5.0.min.js"></script>
		<script src="<?php echo base_url() ?>assets/admin/plugins/jquery-cookie/jquery.cookie.js"></script>
		<script src="<?php echo base_url() ?>assets/admin/plugins/bootstrap-colorpalette/js/bootstrap-colorpalette.js"></script>
		<script src="<?php echo base_url() ?>assets/admin/js/main.js"></script>
		<!-- end: MAIN JAVASCRIPTS -->
		
		<?php if($page_slug == "dashboard"){ ?>		
		<script type="text/javascript">
		$(function () {
		    $('#containergraph').highcharts({
		        title: {
		            text: 'Monthly Resume Status ( Year : 2016 )',
		            x: -20 //center
		        },
		        subtitle: {
		            text: '',
		            x: -20
		        },
		        xAxis: {
		            categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
		                'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
		        },
		        yAxis: {
		            title: {
		                text: 'Emails sended'
		            },
		            plotLines: [{
		                value: 0,
		                width: 0,
		                color: '#0c84f4'
		            }]
		        },
		        tooltip: {
		            valueSuffix: ''
		        },
		        legend: {
		            layout: 'horizontal',
		            align: 'center',
		            verticalAlign: 'bottom',
		            borderWidth: 0
		        },
		        series: [{
		            name: 'Resume Downloaded',
		            data: [3, 7, 8, 2, 10, 2, 13, 16, 5, 9, 10, 9]
		        }, {
		            name: 'Resume Viewed',
		            data: [23, 37, 18, 12, 90, 20, 13, 26, 51, 69, 10, 29]
		        }]
		    });
		});
		</script>		
		<? } ?>

		<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<?php if(count($pageJS) > 0){ 
			foreach ($pageJS as $js) { ?>
			<script src="<?php echo $js ?>"></script>		
		<?php } } ?>
		<script>
			jQuery(document).ready(function() {
				Main.init();
				<?php if(  isset($initJsFunc) && count($initJsFunc) > 0){ 
					foreach ($initJsFunc as $initJS) { ?>
					<?php echo $initJS; ?>	
				<?php } } ?>
			});
		</script>		
		<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
	</body>
	<!-- end: BODY -->
</html>