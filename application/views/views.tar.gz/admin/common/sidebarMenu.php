<div class="navbar-content">
		<!-- start: SIDEBAR -->
		<div class="main-navigation navbar-collapse collapse">
			<!-- start: MAIN NAVIGATION MENU -->
			<ul class="main-navigation-menu">
				<li class=" <?php if($page_slug == 'dashboard'){ echo 'active' ;}?> open">
					<a href="<?php echo base_url()?>dashboard"><i class="clip-home-3"></i>
						<span class="title"> Dashboard </span><span class="selected"></span>
					</a>
				</li>
				<li class=" <?php if($page_slug == 'userlist' || $page_slug == 'jobseekerlist'){ echo 'active' ;}?>" >
					<a href="javascript:void(0)"><i class="clip-user-2"></i>
						<span class="title"> User Section</span><i class="icon-arrow"></i>
						<span class="selected"></span>
					</a>
					<ul class="sub-menu">
						<li>
							<a href="<?php echo base_url()?>admin/userlist">
								<span class="title"> Users List</span>
							</a>
							<a href="<?php echo base_url()?>admin/jobseekerlist">
								<span class="title"> Jobseeker List</span>
							</a>
						</li>						
					</ul>
				</li>
				<li class=" <?php if($page_slug == 'salaryrangelist'){ echo 'active' ;}?> ">
					<a href="<?php echo base_url()?>admin/salaryrangelist"><i class="clip-banknote"></i>
						<span class="title"> Salary Range </span><span class="selected"></span>
					</a>
				</li>
				<li class=" <?php if($page_slug == 'functionalAreaList'){ echo 'active' ;}?> ">
					<a href="<?php echo base_url()?>admin/functionalAreaList"><i class="clip-cube-2"></i>
						<span class="title"> Functional Area </span><span class="selected"></span>
					</a>
				</li>
				<li class=" <?php if($page_slug == 'companylist'){ echo 'active' ;}?> ">
					<a href="<?php echo base_url()?>admin/companylist"><i class="fa fa-briefcase"></i>
						<span class="title"> Company</span><span class="selected"></span>
					</a>
				</li>
				<li class=" <?php if($page_slug == 'jobtypelist'){ echo 'active' ;}?> ">
					<a href="<?php echo base_url()?>admin/jobtypelist"><i class="clip-users"></i>
						<span class="title"> Job Type</span><span class="selected"></span>
					</a>
				</li>				
			</ul>
			<!-- end: MAIN NAVIGATION MENU -->
		</div>
		<!-- end: SIDEBAR -->
</div>