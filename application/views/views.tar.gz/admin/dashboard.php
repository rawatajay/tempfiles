<!-- start: MAIN CONTAINER -->
<div class="main-container">
	<?php include_once('common/sidebarMenu.php') ?>
	<!-- start: PAGE -->
	<div class="main-content">		
		<div class="container">
			<!-- start: PAGE HEADER -->
			<div class="row">
				<div class="col-sm-12">					
					<!-- start: PAGE TITLE & BREADCRUMB -->					
					<div class="page-header">
						<h1>Dashboard</h1>
					</div>
					<!-- end: PAGE TITLE & BREADCRUMB -->
				</div>
			</div>
			<!-- end: PAGE HEADER -->
			<!-- start: PAGE CONTENT -->
			<div class="row">
				<div class="col-sm-4">
					<div class="core-box">
						<div class="heading">
							<i class="clip-user-4 circle-icon circle-green"></i>
							<h2>Manage Users</h2>
						</div>
						<div class="content">
							Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.
						</div>
						<a class="view-more" href="#">
							View More <i class="clip-arrow-right-2"></i>
						</a>
					</div>
				</div>
				<div class="col-sm-4">
					<div class="core-box">
						<div class="heading">
							<i class="clip-clip circle-icon circle-teal"></i>
							<h2>Manage Orders</h2>
						</div>
						<div class="content">
							Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.
						</div>
						<a class="view-more" href="#">
							View More <i class="clip-arrow-right-2"></i>
						</a>
					</div>
				</div>
				<div class="col-sm-4">
					<div class="core-box">
						<div class="heading">
							<i class="clip-database circle-icon circle-bricky"></i>
							<h2>Manage Data</h2>
						</div>
						<div class="content">
							Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat.
						</div>
						<a class="view-more" href="#">
							View More <i class="clip-arrow-right-2"></i>
						</a>
					</div>
				</div>
			</div>
			
			<div class="row">
				<div class="col-sm-7">
					<div class="panel panel-default">
						<div class="panel-heading">
							<i class="clip-stats"></i>
							Resume Status							
						</div>
						<!-- <div class="panel-body">
							<div class="flot-medium-container">
								<div id="placeholder-h1" class="flot-placeholder"></div>
							</div>
						</div> -->

					<div id="containergraph"></div>

						</body>
					</div>
				</div>	
				<div class="col-sm-5">
					<div class="panel panel-default">
						<div class="panel-heading">
							<i class="clip-office-2"></i>
							 Company messages							
						</div>
						<div class="panel-body panel-scroll" style="height:375px">
							<table class="table table-striped table-hover" id="sample-table-1">
								<thead>
									<tr>
										<th class="center">S.No</th>
										<th>Inbox</th>	
										<th>Date</th>																			
									</tr>
								</thead>
								<tbody>
									<tr>
										<td class="center">1</td>
										<td>Lorem ipsum dolor sit amet, consectetuer adipiscing elittd</td>
										<td>Today at 9.23</td>										
									</tr>	
									<tr>
										<td class="center">2</td>
										<td>Lorem ipsum dolor sit amet, consectetuer adipiscing elittd</td>
										<td>Today at 9.23</td>										
									</tr>
									<tr>
										<td class="center">3</td>
										<td>Lorem ipsum dolor sit amet, consectetuer adipiscing elittd</td>
										<td>Today at 9.23</td>										
									</tr>	
									<tr>
										<td class="center">4</td>
										<td>Lorem ipsum dolor sit amet, consectetuer adipiscing elittd</td>
										<td>Today at 9.23</td>										
									</tr>	
									<tr>
										<td class="center">5</td>
										<td>Lorem ipsum dolor sit amet, consectetuer adipiscing elittd</td>
										<td>Today at 9.23</td>										
									</tr>	
									<tr>
										<td class="center">6</td>
										<td>Lorem ipsum dolor sit amet, consectetuer adipiscing elittd</td>
										<td>Today at 9.23</td>										
									</tr>	
									<tr>
										<td class="center">7</td>
										<td>Lorem ipsum dolor sit amet, consectetuer adipiscing elittd</td>
										<td>Today at 9.23</td>										
									</tr>	
									<tr>
										<td class="center">8</td>
										<td>Lorem ipsum dolor sit amet, consectetuer adipiscing elittd</td>
										<td>Today at 9.23</td>										
									</tr>	
									<tr>
										<td class="center">9</td>
										<td>Lorem ipsum dolor sit amet, consectetuer adipiscing elittd</td>
										<td>Today at 9.23</td>										
									</tr>	
									<tr>
										<td class="center">10</td>
										<td>Lorem ipsum dolor sit amet, consectetuer adipiscing elittd</td>
										<td>Today at 9.23</td>										
									</tr>											
								</tbody>
							</table>
						</div>
					</div>
				</div>					
			</div>									
			<!-- end: PAGE CONTENT-->
		</div>
	</div>
	<!-- end: PAGE -->
</div>
<!-- end: MAIN CONTAINER -->
<!-- start: FOOTER -->
<div class="footer clearfix">
	<div class="footer-inner">
		<?php echo COPYRIGHT;?>
	</div>
	<div class="footer-items">
		<span class="go-top"><i class="clip-chevron-up"></i></span>
	</div>
</div>
<!-- end: FOOTER -->