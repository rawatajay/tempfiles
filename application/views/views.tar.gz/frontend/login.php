<!-- start: CSS REQUIRED FOR THIS PAGE ONLY  -->
<link rel="stylesheet" href="<?php echo base_url()?>assets/frontend/plugins/bootstrap-social-buttons/social-buttons-3.css">
<!-- end: CSS REQUIRED FOR THIS PAGE ONLY  -->

<section class="wrapper padding50">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h2 class="center"> Sign In to job seeker account</h1>	
				<p class="center">
						Culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut non libero consectetur adipiscing elit magna. Sed et quam lacus.
					</p>			
				<hr>
			</div>
		</div>
		<div class="row">		
			<div class="col-md-offset-3 col-md-6 jh-form">
				<!-- BEGIN FORM-->
				<button class="btn btn-facebook">
					<i class="fa fa-facebook"></i>
					| Sign In with Facebook
				</button>
				<button class="btn btn-google-plus">
					<i class="fa fa-google-plus"></i>
					| Sign In with Google+
				</button>
				<hr>
				<form role="form" class="horizontal-form margin-bottom-40" action="#">					
					<div class="form-group">
						<label class="control-label">
							Email <span class="symbol required"></span>
						</label>
						<input type="text" placeholder="Email" class="form-control" id="email" name="email">
					</div>
					<div class="form-group">
						<label class="control-label">
							Password <span class="symbol required"></span>
						</label>
						<input type="text" placeholder="Password" class="form-control" id="password" name="password">
					</div>										
					<button class="btn btn-main-color btn-block" type="submit">
						Sign In <i class="fa fa-arrow-circle-right"></i>
					</button>
					<p><a href=""><span>Forgot Password ? Click Here</span></a>
					<a class="text-muted right" href="<?php echo base_url()?>signup"><span>Already have account</span></a>
					</p>
				</form>
				<!-- END FORM-->
			</div>		
		</div>
	</div>
</section>