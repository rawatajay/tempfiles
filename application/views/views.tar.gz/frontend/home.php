<!-- start: MAIN CONTAINER -->
	<div class="main-container">
			<!-- start: REVOLUTION SLIDERS -->
			<section class="fullwidthbanner-container">
				<div class="fullwidthabnner">
					<ul>
						<!-- start: FIRST SLIDE -->
						<li data-transition="fade" data-slotamount="7" data-masterspeed="1500" >
							<img src="<?php echo base_url()?>assets/frontend/images/sliders/slidebg1.jpg"  style="background-color:rgb(246, 246, 246)" alt="slidebg1"  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">
							<div class="caption lft slide_title slide_item_left"
							data-x="300"
							data-y="105"
							data-speed="400"
							data-start="1500"
							data-easing="easeOutExpo">
								Looking for job ?
							</div>
							<div class="caption lft slide_subtitle slide_item_right"
							data-x="430"
							data-y="180"
							data-speed="400"
							data-start="2000"
							data-easing="easeOutExpo">
								What are you waiting for ?
							</div>																		
						</li>
						<!-- end: FIRST SLIDE -->	
						<!-- end: FIRST SLIDE -->
						<!-- start: SECOND SLIDE -->
						<li data-transition="fade" data-slotamount="7" data-masterspeed="1500" >
							<img src="<?php echo base_url()?>assets/frontend/images/sliders/slidebg1.jpg"  style="background-color:rgb(246, 246, 246)" alt="slidebg1"  data-bgfit="cover" data-bgposition="left top" data-bgrepeat="no-repeat">
							<div class="caption lft slide_title slide_item_left"
							data-x="70"
							data-y="105"
							data-speed="400"
							data-start="1500"
							data-easing="easeOutExpo">
								Easiest way to find your dream job
							</div>
							<div class="caption lft slide_subtitle slide_item_left"
							data-x="300"
							data-y="180"
							data-speed="400"
							data-start="2000"
							data-easing="easeOutExpo">
								We will provide the companies satisfying your job profile
							</div>												
						</li>
						<!-- end: SECOND SLIDE -->					
					</ul>
				</div>
			</section>
			<!-- end: REVOLUTION SLIDERS -->
			<section class="padding25">
				<!-- start: CORE BOXES CONTAINER -->
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<h2 class="center">
								<a href="<?php echo base_url()?>searchquery" class="btn btn-primary btn-squared btn-lg">Apply to companies <i class="fa fa-arrow-circle-right"></i></a>								
							</h2>
							<hr>			
						</div>
						
					</div>
				</div>
				<!-- end: CORE BOXES CONTAINER -->
			</section>
			<section class="wrapper  padding25" style="min-height:400px;  background-image: url('<?php echo base_url()?>assets/frontend/images/photodune-4043508-3d-modern-office-room-l.jpg')"  data-stellar-background-ratio="0.8" data-stellar-vertical-offset="-750">
				<!-- start: WORKS CONTAINER -->
				<div class="container">
					<div class="row">
						<div class="col-md-12">
							<h2 class="center white">Take a look at some companies</h2>

							<hr>
							<div class="grid-container animate-group"  data-animation-interval="100">
								<div class="col-md-3 col-sm-6">
									<div class="grid-item animate" style="background-color: white;">
										<div class="grid-content dataset-head">
												<b>Top companies in India</b>
										</div>
										<ul class="dataset-list">
											<li>
												<p>Tata Consultancy Services</p>
											</li>
											<li>
												<p>Reliance</p>
											</li>
											<li>
												<p>HDFC Bank</p>
											</li>
											<li>
												<p>Coal India</p>
											</li>
											<li>
												<p>Sun Pharma</p>
											</li>												
										</ul>									
									</div>
								</div>
								<div class="col-md-3 col-sm-6">
									<div class="grid-item animate" style="background-color: white;">
										<div class="grid-content dataset-head" >
												<b>.Net Comapnies in Delhi NCR</b>
										</div>
										<ul class="dataset-list">
											<li>
												<p>Web Packets</p>
											</li>
											<li>
												<p>Edrubic</p>
											</li>
											<li>
												<p>United Health Group</p>
											</li>
											<li>
												<p>Berger Paints India Limited</p>
											</li>
											<li>
												<p>Carmeet Technologies Pvt. Ltd.</p>
											</li>												
										</ul>									
									</div>
								</div>
								<div class="col-md-3 col-sm-6">
									<div class="grid-item animate" style="background-color: white;">
										<div class="grid-content dataset-head">
												<b>Designer Company in Pune</b>
										</div>
										<ul class="dataset-list">
											<li>
												<p>Imedia</p>
											</li>
											<li>
												<p>Libricon Digital Marketing</p>
											</li>
											<li>
												<p>Exite Tamplate</p>
											</li>
											<li>
												<p>Spectrum Web Infotech</p>
											</li>
											<li>
												<p>Reyes Design Temple</p>
											</li>												
										</ul>									
									</div>
								</div>
								<div class="col-md-3 col-sm-6">
									<div class="grid-item animate" style="background-color: white;">
										<div class="grid-content dataset-head">
												<b>Php Developer</b>
										</div>
										<ul class="dataset-list">
											<li>
												<p>T2S Software Developer</p>
											</li>
											<li>
												<p>Headers Labs India</p>
											</li>
											<li>
												<p>Ricom Technologies</p>
											</li>
											<li>
												<p>Classic Informatics</p>
											</li>
											<li>
												<p>Gbim Technologies</p>
											</li>												
										</ul>									
									</div>
								</div>
					</div>
							<hr>							
						</div>
					</div>
				</div>
				<!-- end: WORKS CONTAINER -->
			</section>
			
			<section class="wrapper padding50">
				<!-- start: BLOG POSTS AND COMMENTS CONTAINER -->
				<div class="container">
					<div class="row">
						<div class="col-md-6">
							<h2>Latest Blog Posts</h2>
							<div class="row recent-posts">
								<div class="flexslider" data-plugin-options='{"directionNav":false, "animation":"slide", "slideshow": false}'>
									<ul class="slides">
										<li>
											<div class="col-md-12">
												<article>
													<span><i class="fa fa-calendar"></i> January 11, 2014 </span>
													<h4>
													<a href="blog_post.html">
														Lorem ipsum dolor sit amet, consectetur adipiscing elit.
													</a></h4>
													<p>
														Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec hendrerit vehicula est, in consequat libero.
													</p>
													<div class="post-meta">
														<span><i class="fa fa-user"></i> By
															<a href="#">
																Peter Clark
															</a> </span>
														<span><i class="fa fa-tag"></i>
															<a href="#">
																Design
															</a>,
															<a href="#">
																Lifestyle
															</a> </span>
														<span><i class="fa fa-comments"></i>
															<a href="#">
																36 Comments
															</a></span>
													</div>
													<a href="#" class="btn btn-xs btn-main-color">
														Read more...
													</a>
												</article>
											</div>
										</li>
										<li>
											<div class="col-md-12">
												<article>
													<span><i class="fa fa-calendar"></i> January 11, 2014 </span>
													<h4>
													<a href="blog_post.html">
														Lorem ipsum dolor sit amet, consectetur adipiscing elit.
													</a></h4>
													<p>
														Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec hendrerit vehicula est, in consequat libero.
													</p>
													<div class="post-meta">
														<span><i class="fa fa-user"></i> By
															<a href="#">
																Peter Clark
															</a> </span>
														<span><i class="fa fa-tag"></i>
															<a href="#">
																Design
															</a>,
															<a href="#">
																Lifestyle
															</a> </span>
														<span><i class="fa fa-comments"></i>
															<a href="#">
																36 Comments
															</a></span>
													</div>
													<a href="#" class="btn btn-xs btn-primary">
														Read more...
													</a>
												</article>
											</div>
										</li>
										<li>
											<div class="col-md-12">
												<article>
													<span><i class="fa fa-calendar"></i> January 11, 2014 </span>
													<h4>
													<a href="blog_post.html">
														Lorem ipsum dolor sit amet, consectetur adipiscing elit.
													</a></h4>
													<p>
														Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec hendrerit vehicula est, in consequat libero.
													</p>
													<div class="post-meta">
														<span><i class="fa fa-user"></i> By
															<a href="#">
																Peter Clark
															</a> </span>
														<span><i class="fa fa-tag"></i>
															<a href="#">
																Design
															</a>,
															<a href="#">
																Lifestyle
															</a> </span>
														<span><i class="fa fa-comments"></i>
															<a href="#">
																36 Comments
															</a></span>
													</div>
													<a href="#" class="btn btn-xs btn-primary">
														Read more...
													</a>
												</article>
											</div>
										</li>
									</ul>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<h2>Testimonials</h2>
							<div class="row">
								<div class="flexslider">
									<ul class="slides">
										<li>
											<div class="col-md-12">
												<blockquote class="testimonial">
													<p>
														Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec hendrerit vehicula est, in consequat. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec hendrerit vehicula est, in consequat.  Donec hendrerit vehicula est, in consequat.  Donec hendrerit vehicula est, in consequat.
													</p>
												</blockquote>
												<div class="testimonial-arrow-down"></div>
												<div class="testimonial-author">
													<div class="img-thumbnail img-thumbnail-small">
														<img src="<?php echo base_url()?>assets/frontend/images/avatar-1.jpg" alt="">
													</div>
													<p>
														<strong>Peter Clark</strong><span>UI Designer - Cliptheme</span>
													</p>
												</div>
											</div>
										</li>
										<li>
											<div class="col-md-12">
												<blockquote class="testimonial">
													<p>
														Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec hendrerit vehicula est, in consequat. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
													</p>
												</blockquote>
												<div class="testimonial-arrow-down"></div>
												<div class="testimonial-author">
													<div class="img-thumbnail img-thumbnail-small">
														<img src="<?php echo base_url()?>assets/frontend/images/avatar-2.jpg" alt="">
													</div>
													<p>
														<strong>Nicole Bell</strong><span>Content Designer - Cliptheme</span>
													</p>
												</div>
											</div>
										</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
				<!-- end: BLOG POSTS AND COMMENTS CONTAINER -->
			</section>
	</div>
<!-- end: MAIN CONTAINER -->		