<!-- start: CSS REQUIRED FOR THIS PAGE ONLY  -->
<link rel="stylesheet" href="<?php echo base_url()?>assets/frontend/plugins/bootstrap-social-buttons/social-buttons-3.css">
<!-- end: CSS REQUIRED FOR THIS PAGE ONLY  -->

<section class="wrapper padding50">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<h2 class="center"> Create job seeker account</h1>	
				<p class="center">
						Culpa qui officia deserunt mollitia animi, id est laborum et dolorum fuga. Et harum quidem rerum facilis est et expedita distinctio lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut non libero consectetur adipiscing elit magna. Sed et quam lacus.
					</p>			
				<hr>
			</div>
		</div>
		<div class="row">		
			<div class="col-md-6 jh-form">
				<!-- BEGIN FORM-->
				<button class="btn btn-facebook">
					<i class="fa fa-facebook"></i>
					| Sign up with Facebook
				</button>
				<button class="btn btn-google-plus">
					<i class="fa fa-google-plus"></i>
					| Sign up with Google+
				</button>
				<hr>
				<form role="form" method="post" class="horizontal-form margin-bottom-40" action="#">
					<div class="form-group">
						<label class="control-label">
							First Name <span class="symbol required"></span>
						</label>
						<input type="text" placeholder="First Name" class="form-control" id="firstname" name="firstname">
					</div>
					<div class="form-group">
						<label class="control-label">
							Last Name <span class="symbol required"></span>
						</label>
						<input type="text" placeholder="Last Name" class="form-control" id="lastname" name="lastname">
					</div>
					<div class="form-group">
						<label class="control-label">
							Email <span class="symbol required"></span>
						</label>
						<input type="text" placeholder="Email" class="form-control" id="email" name="email">
					</div>
					<div class="form-group">
						<label class="control-label">
							Password <span class="symbol required"></span>
						</label>
						<input type="text" placeholder="Password" class="form-control" id="password" name="password">
					</div>		
					<div class="form-group">
						<label class="control-label">
							Notify By <span class="symbol required"></span>
						</label>
						<div class="right">
						<input type="checkbox" id="1" class="checkbox" />
    					<label for="1">Email</label>
    					<input type="checkbox" id="2" class="checkbox" />
    					<label for="2">SMS</label>
    					<input type="checkbox" id="3" class="checkbox" />
    					<label for="3">Call</label>
    					</div>

					</div>
					<div class="form-group">
						<label class="control-label">
							Are you able to Face to Face Interview ? <span class="symbol required"></span>
						</label>
						<div class="right">
						<input type="radio" id="f1" name="f2f" class="checkbox" />
    					<label for="f1">Yes</label>
    					<input type="radio" id="f2" name="f2f" class="checkbox" />
    					<label for="f2">No</label>
    					</div>
					</div>

					<div class="form-group">
						<label class="control-label">
							Other Offers<span class="symbol required"></span>
						</label>
						<div class="right">
						<input type="radio" id="oo1" name="oo" class="checkbox" />
    					<label for="oo1">Yes</label>
    					<input type="radio" id="oo2" name="oo" class="checkbox" />
    					<label for="oo2">No</label>
    					</div>
					</div>	
					<div class="form-group">
						<label class="control-label">
							Is open for bond ? <span class="symbol required"></span>
						</label>
						<div class="right">
						<input type="radio" id="b1" name="ob" class="checkbox" />
    					<label for="b1">Yes</label>
    					<input type="radio" id="b2" name="ob" class="checkbox" />
    					<label for="b2">No</label>
    					</div>
					</div>
					<div class="form-group">	
						<label class="btn btn-default btn-file">
    						Upload Resume Here <input type="file" style="display: none;">
						</label>
					</div>
					<button class="btn btn-main-color btn-block" type="submit">
						Sign Up <i class="fa fa-arrow-circle-right"></i>
					</button>
				</form>
				<!-- END FORM-->
			</div>
			
			<div class="col-md-offset-1 col-md-4">
				<aside class="sidebar">	
					<h3>Latest Blogs</h3>	
					<hr>								
					<div class="tabs">
						<ul class="nav nav-tabs">
							<li class="active">
								<a data-toggle="tab" href="#thisweek"> This Year</a>
							</li>
							<li>
								<a data-toggle="tab" href="#thismonth">
									This Month
								</a>
							</li>
							<li>
								<a data-toggle="tab" href="#thisyear">
									This Week
								</a>
							</li>
						</ul>
						<div class="tab-content">
							<div id="thisweek" class="tab-pane active">
								<ul class="post-list">
									<li>
										<div class="post-image">
											<div class="img-thumbnail">
												<a href="#">
													<img alt="" src="<?php echo base_url() ?>assets/frontend/images/image03_thumb.jpg">
												</a>
											</div>
										</div>
										<div class="post-info">
											<a href="#">
												Nullam Vitae Nibh Un Odiosters
											</a>
											<div class="post-meta">
												Jan 10, 2014
											</div>
										</div>
									</li>
									<li>
										<div class="post-image">
											<div class="img-thumbnail">
												<a href="#">
													<img alt="" src="<?php echo base_url() ?>assets/frontend/images/image04_thumb.jpg">
												</a>
											</div>
										</div>
										<div class="post-info">
											<a href="#">
												Vitae Nibh Un Odiosters
											</a>
											<div class="post-meta">
												Jan 10, 2014
											</div>
										</div>
									</li>
									<li>
										<div class="post-image">
											<div class="img-thumbnail">
												<a href="#">
													<img alt="" src="<?php echo base_url() ?>assets/frontend/images/image05_thumb.jpg">
												</a>
											</div>
										</div>
										<div class="post-info">
											<a href="#">
												Odiosters Nullam Vitae
											</a>
											<div class="post-meta">
												Jan 10, 2014
											</div>
										</div>
									</li>
								</ul>
							</div>
							<div id="thismonth" class="tab-pane">
								<ul class="post-list">
									<li>
										<div class="post-image">
											<div class="img-thumbnail">
												<a href="#">
													<img alt="" src="<?php echo base_url() ?>assets/frontend/images/image03_thumb.jpg">
												</a>
											</div>
										</div>
										<div class="post-info">
											<a href="#">
												Nullam Vitae Nibh Un Odiosters
											</a>
											<div class="post-meta">
												Jan 10, 2014
											</div>
										</div>
									</li>
									<li>
										<div class="post-image">
											<div class="img-thumbnail">
												<a href="#">
													<img alt="" src="<?php echo base_url() ?>assets/frontend/images/image04_thumb.jpg">
												</a>
											</div>
										</div>
										<div class="post-info">
											<a href="#">
												Vitae Nibh Un Odiosters
											</a>
											<div class="post-meta">
												Jan 10, 2014
											</div>
										</div>
									</li>
									<li>
										<div class="post-image">
											<div class="img-thumbnail">
												<a href="#">
													<img alt="" src="<?php echo base_url() ?>assets/frontend/images/image05_thumb.jpg">
												</a>
											</div>
										</div>
										<div class="post-info">
											<a href="#">
												Odiosters Nullam Vitae
											</a>
											<div class="post-meta">
												Jan 10, 2014
											</div>
										</div>
									</li>
								</ul>
							</div>
							<div id="thisyear" class="tab-pane">
								<ul class="post-list">
									<li>
										<div class="post-image">
											<div class="img-thumbnail">
												<a href="#">
													<img alt="" src="<?php echo base_url() ?>assets/frontend/images/image03_thumb.jpg">
												</a>
											</div>
										</div>
										<div class="post-info">
											<a href="#">
												Nullam Vitae Nibh Un Odiosters
											</a>
											<div class="post-meta">
												Jan 10, 2014
											</div>
										</div>
									</li>
									<li>
										<div class="post-image">
											<div class="img-thumbnail">
												<a href="#">
													<img alt="" src="<?php echo base_url() ?>assets/frontend/images/image04_thumb.jpg">
												</a>
											</div>
										</div>
										<div class="post-info">
											<a href="#">
												Vitae Nibh Un Odiosters
											</a>
											<div class="post-meta">
												Jan 10, 2014
											</div>
										</div>
									</li>
									<li>
										<div class="post-image">
											<div class="img-thumbnail">
												<a href="#">
													<img alt="" src="<?php echo base_url() ?>assets/frontend/images/image05_thumb.jpg">
												</a>
											</div>
										</div>
										<div class="post-info">
											<a href="#">
												Odiosters Nullam Vitae
											</a>
											<div class="post-meta">
												Jan 10, 2014
											</div>
										</div>
									</li>
								</ul>
							</div>
						</div>
					</div>				
				</aside>
			</div>
		</div>
	</div>
</section>