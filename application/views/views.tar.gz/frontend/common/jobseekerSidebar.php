<div class="navbar-content">
<!-- start: SIDEBAR -->
<div class="main-navigation navbar-collapse collapse">	
	<!-- start: MAIN NAVIGATION MENU -->
	<ul class="main-navigation-menu">
		<li>
			<img class="circle-img joseeker-profileimg" src="<?php echo base_url()?>assets/admin/images/avatar-1-xl.jpg" alt="">

			<div class="progress progress-striped active" style="width:85%;margin-left:8%">
			  	<div class="progress-bar" role="progressbar" aria-valuenow="70"
			  	aria-valuemin="0" aria-valuemax="100" style="width:70%">
			    70% Profile Completed
			  	</div>
			</div>
		</li>	
		<li >	
			<a href="index.html"><i class="fa fa-dashboard"></i>
				<span class="title"> Dashboard </span><span class="selected"></span>
			</a>
		</li>
		<li>
			<a href="javascript:void(0)"><i class="fa fa-bar-chart-o"></i>
				<span class="title"> Hiring Probability Index </span>		
			</a>			
		</li>
		<li>
			<a href="../../frontend/clip-one/index.html" target="_blank"><i class="fa fa-rupee"></i>
				<span class="title"> Balance Credit </span><span class="selected"></span>
			</a>
		</li>
		<li>
			<a href="javascript:void(0)"><i class="fa fa-group"></i>
				<span class="title"> Refer Friends & Earn  </span>
			</a>			
		</li>
		<li>
			<a href="javascript:void(0)"><i class="fa fa-question-circle
"></i>
				<span class="title"> Ask a question </span>			
			</a>			
		</li>
		<li>
			<a href="javascript:void(0)"><i class="clip-exit"></i>
				<span class="title"> Logout </span>			
			</a>			
		</li>
	</ul>
	<!-- end: MAIN NAVIGATION MENU -->
</div>
<!-- end: SIDEBAR -->