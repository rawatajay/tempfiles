<!-- start: CSS REQUIRED FOR THIS PAGE ONLY  -->
<link rel="stylesheet" href="<?php echo base_url()?>assets/frontend/plugins/bootstrap-social-buttons/social-buttons-3.css">
<!-- end: CSS REQUIRED FOR THIS PAGE ONLY  -->

<section class="wrapper padding50">
	<div class="container">
		<div class="row">		
			<div class="col-md-12 jh-form serachform">
				<!-- BEGIN FORM-->
				<div class="panel panel-default">
								<div class="panel-heading">
									<h3 >Search job as per your need</h3>
								</div>
								<div class="panel-body">
									<form action="#" role="form" class="smart-wizard form-horizontal" id="form">
										<div id="wizard" class="swMain">
											<ul>
												<li>
													<a href="#step-1">
														<div class="stepNumber">
															1
														</div>
														<!-- <span class="stepDesc"> Step 1
															<br />
															<small>Step 1 description</small> </span> -->
													</a>
												</li>
												<li>
													<a href="#step-2">
														<div class="stepNumber">
															2
														</div>
														<!-- <span class="stepDesc"> Step 2
															<br />
															<small>Step 2 description</small> </span> -->
													</a>
												</li>
												<li>
													<a href="#step-3">
														<div class="stepNumber">
															3
														</div>
														<!-- <span class="stepDesc"> Step 3
															<br />
															<small>Step 3 description</small> </span> -->
													</a>
												</li>
												<li>
													<a href="#step-4">
														<div class="stepNumber">
															4
														</div>
														<!-- <span class="stepDesc"> Step 4
															<br />
															<small>Step 4 description</small> </span> -->
													</a>
												</li>
											</ul>
											<!-- <div class="progress progress-striped active progress-sm">
												<div aria-valuemax="100" aria-valuemin="0" role="progressbar" class="progress-bar progress-bar-success step-bar">
													<span class="sr-only"> 0% Complete (success)</span>
												</div>
											</div>  -->

											<div id="step-1" class="col-md-offset-3">
												
												<div class="form-group">
													<label class="col-sm-3 control-label">
														What Are you Looking For?  <span class="symbol required"></span>
													</label>
													<div class="col-sm-7">
														<select  class="form-control search-select search-selectbox" id="dropdown" name="dropdown">
															<option value="">What Are you Looking For?</option>
															<option value="Category 1">Full Time</option>
															<option value="Category 2">Part Time</option>
															<option value="Category 3">Freelance</option>
															<option value="Category 4">Internship</option>
														</select>
													</div>
												</div>
												<div class="form-group">
													<label class="col-sm-3 control-label">
														Where are you Looking For? <span class="symbol required"></span>
													</label>
													<div class="col-sm-7">
														 <select multiple="multiple" class="search-select search-selectbox" id="dropdown" name="dropdown">
															<option value="">Where are you Looking For?</option>
															<option value="India">Anywhere in India</option>
															<optgroup label="Particular cities">
															    <option value="Lucknow">Lucknow</option>
															    <option value="Delhi">Delhi</option>
															    <option value="Nagpur">Nagpur</option>
															    <option value="Pune">Pune</option>
															    <option value="Mumbai">Mumbai</option>
															    <option value="Bangalore">Bangalore</option>
															    <option value="Kerala">Kerala</option>
															 </optgroup>
														</select>
													</div>
												</div>
												<div class="form-group">
													<label class="col-sm-3 control-label">
														Monthly Salary? <span class="symbol required"></span>
													</label>
													<div class="col-sm-7">
														 <select  id="form-field-select-4 search-selectbox" class="form-control search-select search-selectbox">
															<option value="">Monthly Salary?</option>
															<option value="10000">10000 INR</option>
															<option value="10000_20000">10000 INR - 20000 INR</option>
															<option value="20000+">20000 INR and above</option>										
														</select>
													</div>
												</div>
												<div class="form-group">
													<div class="col-sm-2 col-sm-offset-8">
														<button class="btn btn-blue next-step btn-block">
															Next <i class="fa fa-arrow-circle-right"></i>
														</button>
													</div>
												</div>
											</div>
											<div id="step-2">

												<div class="form-group ">
													<label class="col-sm-3 col-sm-3 control-label">
														First Name <span class="symbol required"></span>
													</label>
													<div class="col-sm-7">
													<input type="text" placeholder="First Name" class="form-control" id="firstname" name="firstname">
													</div>
												</div>
												<div class="form-group">
													<label class="col-sm-3 control-label">
														Last Name <span class="symbol required"></span>
													</label>
													<div class="col-sm-7">
													<input type="text" placeholder="Last Name" class="form-control" id="lastname" name="lastname">
													</div>
												</div>
												<div class="form-group">
													<label class="col-sm-3 control-label">
														Email <span class="symbol required"></span>
													</label>
													<div class="col-sm-7">
													<input type="text" placeholder="Email" class="form-control" id="email" name="email">
													</div>
												</div>
												<div class="form-group">
													<label class="col-sm-3 control-label">
														Password <span class="symbol required"></span>
													</label>
													<div class="col-sm-7">
													<input type="text" placeholder="Password" class="form-control" id="password" name="password">
													</div>
												</div>		
												<div class="form-group">
													<label class="col-sm-3 control-label">
														Notify By <span class="symbol required"></span>
													</label>
													<div class="col-sm-7">
													<div class="right">
													<input type="checkbox" id="1" class="checkbox" />
							    					<label for="1">Email</label>
							    					<input type="checkbox" id="2" class="checkbox" />
							    					<label for="2">SMS</label>
							    					<input type="checkbox" id="3" class="checkbox" />
							    					<label for="3">Call</label>
							    					</div>
							    					</div>

												</div>
												<div class="form-group">
													<label class="col-sm-3 control-label">
														Are you able to Face to Face Interview ? <span class="symbol required"></span>
													</label>
													<div class="col-sm-7">
													<div class="right">
													<input type="radio" id="f1" name="f2f" class="checkbox" />
							    					<label for="f1">Yes</label>
							    					<input type="radio" id="f2" name="f2f" class="checkbox" />
							    					<label for="f2">No</label>
							    					</div>
							    					</div>
												</div>

												<div class="form-group">
													<label class="col-sm-3 control-label">
														Other Offers<span class="symbol required"></span>
													</label>
													<div class="col-sm-7">
													<div class="right">
													<input type="radio" id="oo1" name="oo" class="checkbox" />
							    					<label for="oo1">Yes</label>
							    					<input type="radio" id="oo2" name="oo" class="checkbox" />
							    					<label for="oo2">No</label>
							    					</div>
							    					</div>
												</div>	
												<div class="form-group">
													<label class="col-sm-3 control-label">
														Is open for bond ? <span class="symbol required"></span>
													</label>
													<div class="col-sm-7">
													<div class="right">
													<input type="radio" id="b1" name="ob" class="checkbox" />
							    					<label for="b1">Yes</label>
							    					<input type="radio" id="b2" name="ob" class="checkbox" />
							    					<label for="b2">No</label>
							    					</div>
							    					</div>
												</div>
												<div class="form-group">	
													<label class="col-sm-3 control-label">
							    						Upload Resume 
													</label>
													<div class="col-sm-7">
													<label class="col-sm-3 btn btn-info btn-file">
							    						Upload Here <input type="file" style="display: none;">
													</label>
													</div>
												</div>												
												<div class="form-group">
													<div class="col-sm-2 col-sm-offset-3">
														<button class="btn btn-light-grey back-step btn-block">
															<i class="fa fa-circle-arrow-left"></i> Back
														</button>
													</div>
													<div class="col-sm-2 col-sm-offset-3 right">
														<button class="btn btn-blue next-step btn-block">
															Next <i class="fa fa-arrow-circle-right"></i>
														</button>
													</div>
												</div>
											</div>
											<div id="step-3">
												<
												<div class="panel-group accordion-custom accordion-teal" id="accordion">
										<div class="panel panel-default">
											<div class="panel-heading">
												<h4 class="panel-title">
												<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
													<i class="icon-arrow"></i>
													High School Detail
												</a></h4>
											</div>
											<div id="collapseOne" class="panel-collapse collapse in">
												<div class="panel-body">
													<table class="table">
													    <thead>
													      <tr>
													        <th>Percentage</th>
													        <th>Marks Obt.</th>
													        <th>Board/School/University</th>
													        <th>Marksheet</th>
													      </tr>
													    </thead>
													    <tbody>
													      <tr >
													        <td><input type="text" class="form-control" /></td>
													        <td><input type="text" class="form-control" /></td>
													        <td><input type="text" class="form-control" /></td>
													        <td>
													        	<label class="btn btn-default btn-file">
									    						Upload <input type="file" style="display: none;">
																</label>
															</td>	
													      </tr>													     
													    </tbody>
												  </table>
												</div>
											</div>
										</div>
										<div class="panel panel-default">
											<div class="panel-heading">
												<h4 class="panel-title">
												<a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
													<i class="icon-arrow"></i>
													Intermediate Detail
												</a></h4>
											</div>
											<div id="collapseTwo" class="panel-collapse collapse">
												<div class="panel-body">
													<table class="table">
													    <thead>
													      <tr>
													        <th>Percentage</th>
													        <th>Marks Obt.</th>
													        <th>Board/School/University</th>
													        <th>Marksheet</th>
													      </tr>
													    </thead>
													    <tbody>
													      <tr >
													        <td><input type="text" class="form-control" /></td>
													        <td><input type="text" class="form-control" /></td>
													        <td><input type="text" class="form-control" /></td>
													        <td>
													        	<label class="btn btn-default btn-file">
									    						Upload <input type="file" style="display: none;">
																</label>
															</td>	
													      </tr>													     
													    </tbody>
												  </table>
												</div>
											</div>
										</div>
										<div class="panel panel-default">
											<div class="panel-heading">
												<h4 class="panel-title">
												<a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
													<i class="icon-arrow"></i>
													Graduation Detail
												</a></h4>
											</div>
											<div id="collapseThree" class="panel-collapse collapse">
												<div class="panel-body">
													<table class="table">
													    <thead>
													      <tr>
													        <th>Percentage</th>
													        <th>Marks Obt.</th>
													        <th>Board/School/University</th>
													        <th>Marksheet</th>
													      </tr>
													    </thead>
													    <tbody>
													      <tr >
													        <td><input type="text" class="form-control" /></td>
													        <td><input type="text" class="form-control" /></td>
													        <td><input type="text" class="form-control" /></td>
													        <td>
													        	<label class="btn btn-default btn-file">
									    						Upload <input type="file" style="display: none;">
																</label>
															</td>	
													      </tr>													     
													    </tbody>
												  </table>
												</div>
											</div>
										</div>
										<div class="panel panel-default">

											<div class="panel-heading">
												<h4 class="panel-title">
												<a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseFour">
													<i class="icon-arrow"></i>
													Post-Graduation Detail
												</a></h4>
											</div>
											<div id="collapseFour" class="panel-collapse collapse">
												<div class="panel-body">
													<table class="table">
													    <thead>
													      <tr>
													        <th>Percentage</th>
													        <th>Marks Obt.</th>
													         <th>Board/School/University</th>
													        <th>Marksheet</th>
													      </tr>
													    </thead>
													    <tbody>
													      <tr class="primary">
													        <td><input type="text" class="form-control" /></td>
													        <td><input type="text" class="form-control" /></td>
													        <td><input type="text" class="form-control" /></td>
													        <td>
													        	<label class="btn btn-default btn-file">
									    						Upload <input type="file" style="display: none;">
																</label>
															</td>	
													      </tr>													     
													    </tbody>
												  </table>
												</div>
											</div>
										</div>
										<div class="panel panel-default">
											<div class="panel-heading">
												<h4 class="panel-title">
												<a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#accordion" href="#collapseFive">
													<i class="icon-arrow"></i>
													Other Certification
												</a></h4>
											</div>
											<div id="collapseFive" class="panel-collapse collapse">
												<div class="panel-body">
													<label class="btn btn-default btn-file">
						    							Upload <input type="file" style="display: none;">
													</label>
												</div>
											</div>
										</div>
									</div>
												<div class="form-group">
													<div class="col-sm-2 col-sm-offset-3">
														<button class="btn btn-light-grey back-step btn-block">
															<i class="fa fa-circle-arrow-left"></i> Back
														</button>
													</div>
													<div class="col-sm-2 col-sm-offset-3">
														<button class="btn btn-blue next-step btn-block">
															Next <i class="fa fa-arrow-circle-right"></i>
														</button>
													</div>
												</div>
											</div>
											<div id="step-4">	
															
												<div class="form-group">
													<div class="col-sm-4 col-sm-offset-4">
														<button class="btn btn-success finish-step btn-block">
															Click here to go to dashboard <i class="fa fa-arrow-circle-right"></i>
														</button>
													</div>
												</div>
											</div> 
										</div>
									</form>
								</div>
							</div>	
				<!-- END FORM-->
			</div>
			
			
		</div>
	</div>
</section>
<style type="text/css">
	.anchor{
		//display: none !important;
	}
</style>